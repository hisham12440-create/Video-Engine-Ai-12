# Claude Free Android

تطبيق Android بسيط مبني على واجهة Claude الأصلية ويستخدم Puter.js للوصول إلى نماذج Claude المتاحة مجانًا بدون Anthropic API key.

## المبدأ
- التطبيق لا يحتوي على مفتاح Anthropic.
- يسجل المستخدم الدخول بحسابه في Puter.
- التطبيق يكتشف نماذج Claude التي يعرضها Puter بلاحقة `:free` ويعرضها فقط.
- الحصص والحدود يحددها Puter؛ لا يوجد تجاوز لها.
- المحادثات تحفظ محليًا على الجهاز.

## بناء APK عبر GitHub
1. ارفع محتويات هذا المجلد إلى مستودع GitHub.
2. ادخل **Actions**.
3. شغّل **Build Android APK**.
4. بعد نجاح البناء، افتح الـworkflow وحمّل artifact باسم `Claude-Free-debug-apk`.

## تشغيل محلي
يمكن فتح المشروع في Android Studio، أو استخدام Gradle 8.9 وJDK 17.

## ملاحظة عن تسجيل الدخول
التطبيق يشغل صفحة الويب على `http://127.0.0.1:8765` داخل WebView حتى يحصل Puter على Origin صالح بدل `file://`.

## المصادر
- https://docs.puter.com/AI/listModels/
- https://docs.puter.com/Auth/signIn/
- https://docs.puter.com/supported-platforms/
