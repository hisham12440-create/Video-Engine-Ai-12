package com.example.claudefree;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Bitmap;
import android.net.Uri;
import android.view.*;
import android.webkit.*;
import android.widget.*;

public class MainActivity extends Activity {
    static android.content.Context appContext;
    private LocalServer server;
    private WebView web;
    private Dialog popup;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b); appContext=getApplicationContext();
        server=new LocalServer(8765); server.start();
        web=new WebView(this); configure(web);
        setContentView(web);
        new Handler().postDelayed(() -> web.loadUrl("http://127.0.0.1:8765/"), 250);
    }
    private void configure(WebView v) {
        WebSettings s=v.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true); s.setSupportMultipleWindows(true); s.setJavaScriptCanOpenWindowsAutomatically(true); s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE); s.setUserAgentString(s.getUserAgentString()+" ClaudeFreeAndroid/1.0");
        v.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req){ String u=req.getUrl().toString(); if(u.startsWith("http://127.0.0.1:8765") || u.startsWith("https://") || u.startsWith("http://")){ view.loadUrl(u); return true;} return false; }
            @Override public void onPageStarted(WebView view,String url,Bitmap icon){ super.onPageStarted(view,url,icon); }
        });
        v.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onCreateWindow(WebView parent, boolean dialog, boolean userGesture, Message resultMsg){
                WebView child=new WebView(MainActivity.this); configure(child);
                popup=new Dialog(MainActivity.this); popup.setTitle("تسجيل الدخول"); popup.setContentView(child,new ViewGroup.LayoutParams(-1,-1)); popup.show();
                ((WebView.WebViewTransport)resultMsg.obj).setWebView(child); resultMsg.sendToTarget(); return true;
            }
            @Override public void onCloseWindow(WebView window){ if(popup!=null) popup.dismiss(); }
        });
    }
    @Override public void onBackPressed(){ if(web.canGoBack()) web.goBack(); else super.onBackPressed(); }
    @Override protected void onDestroy(){ if(web!=null) web.destroy(); if(server!=null) server.stop(); super.onDestroy(); }
}
