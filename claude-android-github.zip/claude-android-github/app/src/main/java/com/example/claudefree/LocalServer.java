package com.example.claudefree;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;

public class LocalServer {
    private final int port;
    private ServerSocket serverSocket;
    private volatile boolean running;
    public LocalServer(int port) { this.port = port; }
    public void start() {
        Thread t = new Thread(() -> {
            try {
                serverSocket = new ServerSocket(port, 20, InetAddress.getByName("127.0.0.1"));
                running = true;
                while (running) {
                    Socket s = serverSocket.accept();
                    new Thread(() -> handle(s)).start();
                }
            } catch (IOException ignored) { }
        }, "LocalClaudeServer");
        t.setDaemon(true); t.start();
    }
    private void handle(Socket socket) {
        try (Socket s = socket; BufferedReader r = new BufferedReader(new InputStreamReader(s.getInputStream(), StandardCharsets.US_ASCII)); OutputStream out = s.getOutputStream()) {
            String line = r.readLine();
            if (line == null) return;
            String[] parts = line.split(" ");
            String path = parts.length > 1 ? parts[1] : "/";
            String hdr; while ((hdr = r.readLine()) != null && !hdr.isEmpty()) { }
            if (path.equals("/") || path.equals("/index.html")) {
                byte[] data = readAsset("index.html");
                write(out, "200 OK", "text/html; charset=utf-8", data);
            } else {
                write(out, "404 Not Found", "text/plain; charset=utf-8", "Not found".getBytes(StandardCharsets.UTF_8));
            }
        } catch (Exception ignored) { }
    }
    private byte[] readAsset(String name) throws IOException {
        try (InputStream in = MainActivity.appContext.getAssets().open(name); ByteArrayOutputStream b = new ByteArrayOutputStream()) {
            byte[] buf = new byte[8192]; int n; while ((n=in.read(buf))!=-1) b.write(buf,0,n); return b.toByteArray();
        }
    }
    private void write(OutputStream out, String status, String type, byte[] data) throws IOException {
        String h = "HTTP/1.1 " + status + "\r\nContent-Type: " + type + "\r\nContent-Length: " + data.length + "\r\nCache-Control: no-store\r\nConnection: close\r\n\r\n";
        out.write(h.getBytes(StandardCharsets.US_ASCII)); out.write(data); out.flush();
    }
    public void stop() { running=false; try { if(serverSocket!=null) serverSocket.close(); } catch(Exception ignored){} }
}
